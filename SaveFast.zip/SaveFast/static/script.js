function toggleMode() {
    document.body.classList.toggle("light");
}
async function analyze() {
    let url = document.getElementById("url").value;
    let res = await fetch('/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
    });
    let data = await res.json();
    let result = document.getElementById("result");
    if (data.error) {
        result.innerHTML = data.error;
        return;
    }
    if (data.playlist) {
        let html = "<h3>Playlist</h3>";
        data.videos.forEach(v => { html += `<p>${v.title}</p>`; });
        html += `<button onclick="downloadPlaylist('${url}')">Download All</button>`;
        result.innerHTML = html;
        return;
    }
    let html = `<h3>${data.title}</h3><img src="${data.thumbnail}" width="200"><br>`;
    data.formats.forEach(f => {
        html += `<button onclick="download('${url}', '${f.format_id}')">${f.quality}</button>`;
    });
    result.innerHTML = html;
}
async function download(url, format_id) {
    let res = await fetch('/download', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url, format_id })
    });
    let data = await res.json();
    window.open(data.url, "_blank");
}
async function downloadPlaylist(url) {
    let res = await fetch('/download_playlist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url })
    });
    let data = await res.json();
    data.links.forEach(link => window.open(link));
}