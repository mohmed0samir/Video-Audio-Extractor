from flask import Flask, render_template, request, jsonify
import yt_dlp
import re
import time
from functools import wraps

app = Flask(__name__)

# Rate limiting بسيط
requests_log = {}
def rate_limit(limit=10, per=60):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            ip = request.remote_addr
            now = time.time()
            requests_log.setdefault(ip, []).append(now)
            requests_log[ip] = [t for t in requests_log[ip] if now - t < per]
            if len(requests_log[ip]) > limit:
                return jsonify({"error": "Too many requests"}), 429
            return f(*args, **kwargs)
        return wrapped
    return decorator

# Validate URL
def is_valid_url(url):
    return re.match(r'https?://', url)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/analyze', methods=['POST'])
@rate_limit()
def analyze():
    url = request.json.get('url')
    if not url or not is_valid_url(url):
        return jsonify({"error": "Invalid link"})
    try:
        ydl_opts = {'quiet': True}
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
        if 'entries' in info:
            videos = [{"title": e.get("title"), "url": e.get("webpage_url")} for e in info['entries'][:20]]
            return jsonify({"playlist": True, "videos": videos})
        formats = [{"format_id": f['format_id'], "quality": f"{f['height']}p"} for f in info.get('formats', []) if f.get('height') and f.get('filesize', 0)<100_000_000]
        return jsonify({"title": info.get("title"), "thumbnail": info.get("thumbnail"), "duration": info.get("duration"), "formats": formats})
    except:
        return jsonify({"error": "Unsupported platform"})

@app.route('/download', methods=['POST'])
@rate_limit()
def download():
    url = request.json.get('url')
    format_id = request.json.get('format_id')
    try:
        ydl_opts = {'quiet': True, 'format': format_id}
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
        return jsonify({"url": info['url']})
    except:
        return jsonify({"error": "Download failed"})

@app.route('/download_playlist', methods=['POST'])
@rate_limit()
def download_playlist():
    url = request.json.get('url')
    try:
        ydl_opts = {'quiet': True}
        links = []
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
        for entry in info['entries']:
            with yt_dlp.YoutubeDL({'quiet': True}) as ydl:
                video = ydl.extract_info(entry['webpage_url'], download=False)
                links.append(video['url'])
        return jsonify({"links": links})
    except:
        return jsonify({"error": "Download failed"})

if __name__ == '__main__':
    import os
    port = int(os.environ.get("PORT", 5000))
    app.run(host="0.0.0.0", port=port)